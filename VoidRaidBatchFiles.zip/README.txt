Add these deck to your customdecks.txt then double click the batch file to have it start.




VR1:Barracus, Deserted Baughe, Tazerecca, Arch Nova Elite, Dreamreaper, Spiteful Raptor, Dune Runner, Lurker Behemoth, Serak Unbound, Baughe
VR2:barracus, Tazerecca, Dreamhaunter, steadfast assailant, Arch Nova Alpha, judgment nova, baughe, jilted baughe, Bane of Truth
VR3:barracus, Sacred Sanctuary, withersnare, dreamreaper, croc oppressor, Arch Nova Alpha, aggeroth choas, serraco lord,  xanadu ultra
VR4:Constantine, Sacred Sanctuary, Bolt Crag, Zodiac Harbinger, Sultan, Deathsteel Falcion, Samurai, Aasi Revealed, Rising Virtue, Precursor Idealist, Dignified Vigil
VR5:kylen, Sacred Sanctuary, Tazerecca, demi constrictor, dreamreaper, Xillanail, Arch Nova Alpha, halerift
VR6:Barracus, auger ream, Xillanail, Tazerecca, Bane of Truth, baughe x2, Tumblox, ezamit  serene, Arch Nova Alpha 
VR7:barracus, Xillanail, Aggeroth chaos, jet, ezamit serene, dreamreaper, auger bore, ayrkrane syn, tazerious, Arch Nova alpha, stealthy niaq, 
VR8:barracus, Sculpted Aegis, Tazerecca, xeno suzerin, demi constrictor, Bane of Truth, Xillanail, Arch Nova Alpha
VR9:Nexor, Sage Ascendant, Xillanail, Ezamit Serene, Xeno Suzerain, Dreamhaunter, Arch Nova Elite, Demi Constrictor, Deserted Baughe 
VR10:Barracus, Demi Constrictor, Tazerious, Arch Nova Alpha, Xillanail, Abhorrent Recluse, Noble Defiance, Ez Serene
VR11:Halcyon, Halerift, Guardian Gamut, Demi Constrictor, Sculpted Aegis, Steel Ram, Stinger Battalion, Sacred Sanctuary, Abhorrent Recluse, Deserted Baughe
VR12:Constantine, Smite Forger, Zodiac Harbinger (2), lightning crag, noble defiance, containment purifier, Heroic Knight, Dreamreaper, Deranged Fanatic, Animus Geist
VR13:Kylen, Demi Constrictor, Arch Nova Alpha, Dreamhaunter, Xillanail, Nexusis, Xanadu Ultra, Tazerecca, Sacred Sanctuary, Coldheart
VR14:Constantine, Smite Forger, Zodiac Harbinger, Sacred Sanctuary, Coldheart, Ezamit Serene, Heroic Knight, Zodiac Harbinger #2, Dreamreaper, Deranged Fanatic
VR15:Barracus, Xillanail, Inferno Demon, Tazerecca, Jet, Arch Nova Alpha, Dreamhaunter, Jilted Baughe, Bane of Truth, Jilted Baughe
VR16:constantine, Sacred Sanctuary, noble defiance (2), zodiac harbinger (2), deranged fanatic, Honorable Samurai, heroic knight, smite forger, 
VR17:barracus, baughe (2), Arch Nova Alpha, Xillanail, Bane of Truth, Inferno Demon, tumblox, Dreamhaunter
VR18:Nexor, Dreamhaunter, Xillanail, Arch Nova Alpha, Abhorrent Recluse, Sacred Sanctuary, Noble Defiance, Tazerecca, Ezamit Serene
VR19:Barracus, Xillanail, Tartarus Graft, Arch Nova Alpha, Ayrkrane Syn, Dream Haunter, Tazerious, Auger Ream, Trampling Anvil, Sacred Sanctuary
VR20:constantine, zodiac harbinger (3), dreamreaper, containment purifier, deathsteel falcion, heroic knight, smite forger, ezamit serene, jet    
VR21:barracus, Tazerecca, xeno suzerin, auger bore, steadfast assailant, Arch Nova Alpha, demi constrictor, Xillanail, jilted baughe, Bane of Truth
VR22:Kylen, Xillanail, Inferno Demon, Lurker Behemoth, Fenlord, Demi Constrictor, Decorated Marshall, Arch Nova Elite, Sacred Sanctuary, Jilted Baughe, Dreamhaunter
VR23:Barracus, Xillanail, Jilted Baughe, Jilted Baughe, Bane of Truth, Xanadu Ultra, Abhorrent Recluse, Steadfast Assailant, Arch Nova Alpha, Coldheart, Auger Ream
VR24:Halcyon, Sculpted Aegis, galereaver, auger bore, dreamreaper, hephatat stoic, Bane of Truth, octane's bulwark, stinger battalion, ezamit serene
VR25:Constantine, Zodiac Harbinger (4), Contaminant Purifier, Xillanail, Honorable Samurai, Dreamreaper, Ezamit Serene, Coldheart
VR26:Arkadios,  Demi Constrictor,  The Adversary,  Arch Nova Elite,  Sacred Sanctuary, Abhorrent Recluse,  Jilted Baughe,  Auger Ream, Bane of Truth
VR27:Barracus, Arch Nova Alpha, Steadfast Assailant, Sculpted Aegis, Dreamreaper, Tazerecca, Bane of Truth, Tumblox, Demon of Flame, Jilted Baughe, Dreamreaper
VR28:Arkadios, Gehenna Cursed(1), Hellwing(2), Erebus City Sector(2), Dreamhaunter, Abhorrent Recluse, Razor Pinion, Belfryze
VR29:barracus, Dreamhaunter, Sacred Sanctuary, Tazerecca, demi constrictor, Bane of Truth, Xillanail, Arch Nova Alpha, Honorable Samurai, Abhorrent Recluse, Stoneheart
VR30:barracus, zodiac harbinger (2), baughe (2), demi constrictor, auger bore, deranged fanatic, Arch Nova Alpha, jet, greatheart
VR31:barracus, tempest keep, Sculpted Aegis, tumblox, demi constrictor, Bane of Truth, Xillanail, Arch Nova Alpha, nefarious hellspont, guardian gamut, Shock Disruptor
VR33:Halcyon, Octane's Bastion, Phase Lancer, Steadfast Assailant, Cadmus the Dragon, Guardian Gamut, Sculpted Aegis (2), Galereaver, Blackrock Cleaver, Halerift
VR34:Barracus, Dreamhaunter, Arch Nova Alpha, Xillanail, Tazerecca, Elite Squadron, Steadfsat Assailant
VR36:kylen, arch nova elite (2), judgment nova, dreamreaper, demi constrictor, revolt ranger, baughe, ezamit serene
VR37:barracus, jilted baughe, Arch Nova Alpha, Xillanail, Inferno Demon, dreamreaper, demi constrictor, Sculpted Aegis, auger bore,  charincinerator
VR38:barracus, Sacred Sanctuary, Tazerecca, Bane of Truth, Xillanail, Arch Nova Alpha, jilted baughe, trench hurler, ezamit serene
VR39:Nexor,Abhorrent Recluse, Dreamreaper, Xillanail, Dune Runner, Constrictor, Baughe, Baughe, Sacred Sanctuary, Tumblox, Ezamit Serene
VR40:Barracus, Auger Ream, Arch Nova Alpha, Nexusis, Bane of Truth, Deathsteel Falchion, Xillanail, Jilted Baughe, Dreamreaper, Ezamit Serene, Jilted Baughe
VR41:barracus, demi constrictor, Tazerecca, auger bore, Bane of Truth, arch nova, alpha,Xillanail, trench hurler
VR43:Halcyon, Guardian Gamut (2), Galereaver, Garrison Fortifier, Indestructible Troop, Auger Ream, Hepathat Stoic, Sculpted Aegis, Sacred Sanctuary
VR44:Halcyon, Halerift, Ezamit Serene, Trench Hurler, Heroic Knight, Arch Nova Alpha, Bane of Truth, Auger Ream, Steadfast Assailant, Sculpted Aegis, Shining Sanctuary
VR45:Cyrus, Infantry
VR47:nexor, xeno suzerain, demi constrictor, samurai, Lurker Behemoth, Xillanail, Arch Nova Alpha, fenlord, jilted baughe, ezamit serene, xanadu ultra
VR48:barracus, Arch Nova Alpha, demi constrictor, auger ream, Tazerecca, Dreamhaunter, Sacred Sanctuary, Lurker Behemoth, Incog Niaq, Xillanail
VR50:barracus, Sacred Sanctuary, Sculpted Aegis, xeno suzerain, demi constrictor (2), Arch Nova Alpha, jilted baughe, ezamit serene

void: /^VR.*$/
